Qwen3.6 borrowed-expert lifetime evidence

Code under test: e2a0868ef57630883f1269e765ee4a69a366409d
Model-free CPU tests only; no model inference or real GPU execution.
macos/ preserves local pre-commit logs and mutation evidence.
ci/ preserves the successful Linux/Windows run and environment metadata.
Historical records are preserved unchanged, including descriptions of the
pre-commit workspace. Their source hashes identify the tested implementation.
MANIFEST.json records SHA-256 for every original evidence file.
The subsequent documentation completion does not change tested runtime code.
Validation must be reassessed when model inference becomes feasible or
additional validation methods become available.
