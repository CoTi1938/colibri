# Local validation evidence: Qwen3.6 borrowed expert lifetime

The reviewable implementation is on `fix/qwen36-expert-borrowing`. No commit or push was made when these artifacts were prepared.

- `review.patch`: complete five-file diff, including the new test and documentation; checked for clean application to the refreshed base.
- `manifest.json`: source/evidence hashes, tested configurations, outcomes and exclusions.
- `*.log`: raw compiler/test output. CUDA-labelled related tests use the fake backend; no real GPU work or model inference ran for this repair.
- `check_mutations.py`: portable negative-control runner, tested with the four recorded mutations.
- `upstream-refresh.txt`: dated `origin/dev` refresh and exact revision.

Full audit and commands: `docs/qwen36-borrowing.md` in the patched checkout. This evidence directory is local review material, separate from the proposed source/documentation commit.

## Negative controls

From a checkout containing the proposed patch:

```sh
python3 model-inspection/qwen36-borrow-validation/check_mutations.py --repo .
```

The script exports the identified **local Git revision** to a temporary directory, copies the patched engine/test there, and introduces one defect at a time. It never edits the checkout or fetches a checkpoint. All four mutants must exit nonzero. The pinned-fallback mutation intentionally triggers the test's missing-progress-event timeout (about 20 seconds).

The script prints its evidence directory. It requires Python 3, Git, tar and clang; its execution was validated on the documented macOS platform only.

The upstream reproducer's exit 1 and the mutation exits are **expected negative results**, not successful engine validation. Serial/OpenMP and sanitizer logs contain the successful patched runs.

## Review

```sh
git apply --stat model-inspection/qwen36-borrow-validation/review.patch
```

Do not apply the patch over the already-modified working tree. Attach the evidence directory or archive to the PR when submitting. Linux/Windows CI and model-based validation are not represented by these logs.
