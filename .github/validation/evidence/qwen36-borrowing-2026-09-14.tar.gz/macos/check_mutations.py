#!/usr/bin/env python3
"""Reproduce model-free negative controls in a disposable tree; never edit the checkout."""
import argparse
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--repo', type=Path, default=Path.cwd(), help='patched Colibri checkout')
ap.add_argument('--base', default='1efb7c82a0c473984cc0258bfc9e12c0cae94914', help='local Git revision providing dependencies')
ap.add_argument('--cc', default='clang')
ap.add_argument('--out', type=Path, help='new evidence directory (default: temporary directory)')
args = ap.parse_args()
repo = args.repo.resolve()
root = args.out.resolve() if args.out else Path(tempfile.mkdtemp(prefix='qwen36-borrow-mutations.'))
if args.out:
    root.mkdir(parents=True, exist_ok=False)
work = root / 'source'
work.mkdir()
archive = subprocess.Popen(['git', '-C', str(repo), 'archive', '--format=tar', args.base, 'c'], stdout=subprocess.PIPE)
try:
    extracted = subprocess.run(['tar', '-xf', '-', '-C', str(work)], stdin=archive.stdout)
finally:
    archive.stdout.close()
if archive.wait() or extracted.returncode:
    raise SystemExit('Could not export the local base revision')
work = work / 'c'
source = (repo / 'c/qwen36.c').read_text()
shutil.copy2(repo / 'c/tests/test_qwen36_borrow.c', work / 'tests/test_qwen36_borrow.c')
common = [args.cc, '-std=gnu11', '-O3', '-Wall', '-Wextra', '-Wno-unused-function',
          '-Wno-unused-parameter', '-Wno-misleading-indentation',
          str(work / 'tests/test_qwen36_borrow.c'), '-lm', '-pthread']
mutants = [
    ('fallback_ignores_borrows',
     'if (s->eid < 0 || s->borrows || (!allow_pinned && s->pinned)) continue;',
     'if (s->eid < 0 || (!allow_pinned && (s->borrows || s->pinned))) continue;'),
    ('prefetch_ignores_borrows',
     'int lru = expert_victim(lc, 0);',
     'int lru = -1; for (int i = 0; i < lc->n; i++) { '
     'if (lc->slots[i].eid < 0 || lc->slots[i].pinned) continue; '
     'if (lru < 0 || lc->slots[i].used < lc->slots[lru].used) lru = i; }'),
    ('prefetch_ignores_demand_claim',
     'if (lc->demand_gathers) { m->is_queued[layer*c->n_experts+eid]=0; pthread_mutex_unlock(&g_pilot_mx); return; }',
     '/* Negative control: omit demand priority. */'),
    ('release_only_once_per_distinct_slot',
     'if (!slots[i]->borrows) abort();\n        slots[i]->borrows--;',
     'if (!slots[i]->borrows) abort();\n'
     '        for (int j = i + 1; j < n; j++) if (slots[j] == slots[i]) slots[j] = NULL;\n'
     '        slots[i]->borrows--;'),
]
results = []
try:
    for name, old, new in mutants:
        if source.count(old) != 1:
            raise SystemExit('Mutation anchor no longer matches exactly: ' + name)
        (work / 'qwen36.c').write_text(source.replace(old, new))
        binary = root / ('mutant-' + name)
        with (root / (name + '-build.log')).open('w') as log:
            subprocess.run(common + ['-o', str(binary)], stdout=log, stderr=subprocess.STDOUT, check=True)
        with (root / (name + '.log')).open('w') as log:
            result = subprocess.run([str(binary)], stdout=log, stderr=subprocess.STDOUT, timeout=100)
        entry = {'mutation': name, 'exit_code': result.returncode, 'detected': result.returncode != 0}
        results.append(entry)
        print(entry, flush=True)
        if result.returncode == 0:
            raise SystemExit('Negative control unexpectedly passed: ' + name)
finally:
    (work / 'qwen36.c').write_text(source)
    (root / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
print('Evidence directory:', root)
